﻿namespace DomainModel;

public class Bus
{
     public int Id { get; set;}

     public int BusNumber {get; set;}
}
